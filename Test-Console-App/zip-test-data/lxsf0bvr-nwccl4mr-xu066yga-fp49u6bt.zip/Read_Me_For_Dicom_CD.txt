﻿EasyRadiology (c) EasyRadiology GmbH 2019-2021
https://www.easyradiology.net

EasyRadiology was invented by Dr. Martin Weihrauch


HOW TO EXTRACT THE DICOM_CD FOLDER FROM THE ARCHIVE
***************************************************

The EasyRadiology Image Format (ERI format) uses military grade encryption (AES 256) to protect the patient's data.
Therefore, the folder in this archive labeled "DICOM_CD" is encrypted with ZIP/AES-256. 

To extract, please follow these steps:

1.	Use a professional ZIP software, not the standard Windows Explorer as this currently does not support AES.
	There is a free software, 7Zip, which works well on all platforms. 

2.  In the Email or Letter, which you have received for this exam, there is a "DICOM Password", which has 32 characters,
	separated by "-". An example is: QI6zaUB4-eTyvc4Jw-fty47SgA-KsxNZAU4 

3.	Now, the ZIP software should decrypt the entire, original DICOM_CD directory.

If you have any questions, please don't hesitate to contact us!