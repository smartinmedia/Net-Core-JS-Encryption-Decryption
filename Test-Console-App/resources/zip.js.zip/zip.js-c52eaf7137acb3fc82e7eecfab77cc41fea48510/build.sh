#!/bin/sh

npx rollup -c rollup-inline-worker.config.js
npx rollup -c