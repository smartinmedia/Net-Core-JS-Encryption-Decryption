/* global zip */

// configure all test cases.